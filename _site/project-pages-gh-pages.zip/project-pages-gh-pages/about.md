---
layout: page
title: "About"
description: "Why use Project Pages?"
header-img: "img/home-bg.jpg"
---

Project Pages is a research blog tool that allows you to quickly show your latest results to an advisor, collaborators or your mom.
	